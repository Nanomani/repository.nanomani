[![Add-on for Kodi](https://img.shields.io/badge/Add--on%20for-Kodi-17B2E7?logo=kodi)](https://forum.kodi.tv/showthread.php?tid=387634)
![Python](https://img.shields.io/badge/Python-3.0%2B-green?logo=python)
[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-orange.svg)](https://creativecommons.org/licenses/by-nc-sa/4.0/)
## Arctic: Zephyr - Rounded

Arctic: Zephyr Rounded is a Kodi skin inspired by Arctic: Zephyr - Reloaded (and AH2) while following its own direction.
Over the years, many features have been removed, added, redesigned, or completely reworked to better align with the goals of this project.

<img width="1920" height="1080" alt="screenshot00005" src="https://github.com/user-attachments/assets/e975cdc5-a5dc-4bfa-9b43-02a8dda8c8fc" />

<img width="1920" height="1080" alt="screenshot00028" src="https://github.com/user-attachments/assets/735f1c25-d2a8-4709-9f36-2cd0577f8d0c" />

## Installation for Kodi Piers:

1. In Kodi Settings > System > Add-ons :
- Unknown Sources: "Enable"
- Update official add-ons from: "Any repositories"

2. Install nanomani repo from direct ZIP install:
- Download: [repository.nanomani-1.0.zip](https://github.com/Nanomani/repository.nanomani/releases/download/v1.0/repository.nanomani-1.0.zip)
  
3. Install from Nanomani repo :
- Nanomani Repository > Add-on repository > Jurialmunkey Alpha Repo

4. Install from Nanomani repo
- Nanomani Repository > Look and Feel > Skins > Arctic Zephir Rounded

## Installation for Kodi Omega:

1. In Kodi Settings > System > Add-ons :
- Unknown Sources: "Enable"
- Update official add-ons from: "Any repositories"

2. Install nanomani repo from direct ZIP install:
- Download: [repository.nanomani-0.9.zip](https://github.com/Nanomani/repository.omega.nanomani/releases/download/v0.9/repository.nanomani-0.9.zip)
  
3. Install from Nanomani repo :
- Nanomani Repository > Add-on repository > Jurialmunkey Alpha Repo

4. Install from Nanomani repo
- Nanomani Repository > Look and Feel > Skins > Arctic Zephir Rounded  

5. After Skin installation "Restart" Kodi or manually check for updates
- Kodi > Settings > Add-ons > Check for updates

### 👉 **[Forum Kodi](https://forum.kodi.tv/showthread.php?tid=387634)**  

## Credits

All credit goes to the original author and creator of the Skin.  
[jurialmunkey](https://github.com/jurialmunkey)
